import React, { useState } from 'react';
import { User, Award, BookOpen, Star, Edit2, Save, X, Building2, GraduationCap, DollarSign, TrendingUp } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export const Profile: React.FC = () => {
  const { user, updateUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user?.name || '',
    bio: user?.bio || '',
    skills: user?.skills ? user.skills.join(', ') : '',
    companyName: user?.companyInfo?.companyName || '',
    industry: user?.companyInfo?.industry || '',
    website: user?.companyInfo?.website || '',
    companyDescription: user?.companyInfo?.description || ''
  });

  if (!user) return null;

  const handleSave = () => {
    const updatedData: any = {
      name: editForm.name,
      bio: editForm.bio
    };

    if (user.role === 'student') {
      updatedData.skills = editForm.skills.split(',').map(s => s.trim()).filter(s => s);
    }

    if (user.role === 'company') {
      updatedData.companyInfo = {
        ...user.companyInfo,
        companyName: editForm.companyName,
        industry: editForm.industry,
        website: editForm.website,
        description: editForm.companyDescription
      };
    }

    updateUser(updatedData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditForm({
      name: user.name,
      bio: user.bio || '',
      skills: user.skills ? user.skills.join(', ') : '',
      companyName: user.companyInfo?.companyName || '',
      industry: user.companyInfo?.industry || '',
      website: user.companyInfo?.website || '',
      companyDescription: user.companyInfo?.description || ''
    });
    setIsEditing(false);
  };

  const getProfileIcon = () => {
    switch (user.role) {
      case 'company':
        return <Building2 className="h-16 w-16 text-blue-500" />;
      case 'teacher':
        return <GraduationCap className="h-16 w-16 text-purple-500" />;
      default:
        return <User className="h-16 w-16 text-gray-400" />;
    }
  };

  const getHeaderGradient = () => {
    switch (user.role) {
      case 'company':
        return 'bg-gradient-to-r from-blue-600 to-cyan-600';
      case 'teacher':
        return 'bg-gradient-to-r from-purple-600 to-pink-600';
      default:
        return 'bg-gradient-to-r from-blue-600 to-purple-600';
    }
  };

  const getRoleText = () => {
    switch (user.role) {
      case 'company':
        return 'Компания-партнер';
      case 'teacher':
        return 'Преподаватель';
      case 'student':
        return 'Студент';
      default:
        return user.role;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        {/* Header */}
        <div className={`${getHeaderGradient()} h-32 relative`}>
          <div className="absolute -bottom-16 left-8">
            <div className="w-32 h-32 bg-white rounded-full border-4 border-white shadow-lg flex items-center justify-center">
              {getProfileIcon()}
            </div>
          </div>
          
          <div className="absolute top-4 right-4">
            {!isEditing ? (
              <button
                onClick={() => setIsEditing(true)}
                className="bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-lg hover:bg-white/30 transition-colors flex items-center space-x-2"
              >
                <Edit2 className="h-4 w-4" />
                <span>Редактировать</span>
              </button>
            ) : (
              <div className="flex space-x-2">
                <button
                  onClick={handleSave}
                  className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors flex items-center space-x-2"
                >
                  <Save className="h-4 w-4" />
                  <span>Сохранить</span>
                </button>
                <button
                  onClick={handleCancel}
                  className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors flex items-center space-x-2"
                >
                  <X className="h-4 w-4" />
                  <span>Отмена</span>
                </button>
              </div>
            )}
          </div>

          {/* Partnership level for companies */}
          {user.role === 'company' && user.companyInfo?.partnershipLevel && (
            <div className="absolute top-4 left-4">
              <div className={`px-3 py-1 rounded-full text-white text-sm font-semibold ${
                user.companyInfo.partnershipLevel === 'platinum' ? 'bg-gray-800' :
                user.companyInfo.partnershipLevel === 'gold' ? 'bg-yellow-500' :
                user.companyInfo.partnershipLevel === 'silver' ? 'bg-gray-400' :
                'bg-orange-600'
              }`}>
                {user.companyInfo.partnershipLevel.toUpperCase()} партнер
              </div>
            </div>
          )}
        </div>

        {/* Profile Info */}
        <div className="pt-20 pb-8 px-8">
          <div className="mb-6">
            {isEditing ? (
              <input
                type="text"
                value={editForm.name}
                onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                className="text-3xl font-bold text-gray-900 bg-transparent border-b-2 border-blue-500 focus:outline-none"
              />
            ) : (
              <h1 className="text-3xl font-bold text-gray-900">{user.name}</h1>
            )}
            <p className="text-gray-600">{getRoleText()}</p>
            {user.role === 'company' && user.companyInfo && (
              <p className="text-sm text-gray-500">{user.companyInfo.industry}</p>
            )}
          </div>

          {/* Stats for students */}
          {user.role === 'student' && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-xl p-6 text-white">
                <div className="flex items-center space-x-3">
                  <Award className="h-8 w-8" />
                  <div>
                    <p className="text-2xl font-bold">{user.academicPoints || 0}</p>
                    <p className="text-yellow-100">Академические баллы</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-green-400 to-blue-500 rounded-xl p-6 text-white">
                <div className="flex items-center space-x-3">
                  <BookOpen className="h-8 w-8" />
                  <div>
                    <p className="text-2xl font-bold">{user.completedTasks || 0}</p>
                    <p className="text-green-100">Выполнено заданий</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-purple-400 to-pink-500 rounded-xl p-6 text-white">
                <div className="flex items-center space-x-3">
                  <Star className="h-8 w-8" />
                  <div>
                    <p className="text-2xl font-bold">{user.rating?.toFixed(1) || '0.0'}</p>
                    <p className="text-purple-100">Рейтинг</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-emerald-400 to-teal-500 rounded-xl p-6 text-white">
                <div className="flex items-center space-x-3">
                  <DollarSign className="h-8 w-8" />
                  <div>
                    <p className="text-2xl font-bold">{(user.totalEarnings || 0).toLocaleString()}₽</p>
                    <p className="text-emerald-100">Заработано</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Company info */}
          {user.role === 'company' && user.companyInfo && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-gradient-to-r from-blue-400 to-cyan-500 rounded-xl p-6 text-white">
                <div className="flex items-center space-x-3">
                  <Building2 className="h-8 w-8" />
                  <div>
                    <p className="text-lg font-bold">{user.companyInfo.size}</p>
                    <p className="text-blue-100">Размер компании</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-purple-400 to-pink-500 rounded-xl p-6 text-white">
                <div className="flex items-center space-x-3">
                  <TrendingUp className="h-8 w-8" />
                  <div>
                    <p className="text-lg font-bold">{user.companyInfo.partnershipLevel}</p>
                    <p className="text-purple-100">Уровень партнерства</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-green-400 to-emerald-500 rounded-xl p-6 text-white">
                <div className="flex items-center space-x-3">
                  <Star className="h-8 w-8" />
                  <div>
                    <p className="text-lg font-bold">Активен</p>
                    <p className="text-green-100">Статус</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Company details for editing */}
          {user.role === 'company' && isEditing && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Название компании
                </label>
                <input
                  type="text"
                  value={editForm.companyName}
                  onChange={(e) => setEditForm({...editForm, companyName: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Отрасль
                </label>
                <input
                  type="text"
                  value={editForm.industry}
                  onChange={(e) => setEditForm({...editForm, industry: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Сайт компании
                </label>
                <input
                  type="url"
                  value={editForm.website}
                  onChange={(e) => setEditForm({...editForm, website: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          )}

          {/* Bio */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              {user.role === 'company' ? 'О компании' : 'О себе'}
            </h2>
            {isEditing ? (
              <textarea
                value={user.role === 'company' ? editForm.companyDescription : editForm.bio}
                onChange={(e) => setEditForm({
                  ...editForm, 
                  [user.role === 'company' ? 'companyDescription' : 'bio']: e.target.value
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={4}
                placeholder={user.role === 'company' ? 'Расскажите о вашей компании...' : 'Расскажите о себе...'}
              />
            ) : (
              <p className="text-gray-600">
                {user.role === 'company' 
                  ? (user.companyInfo?.description || 'Информация не заполнена')
                  : (user.bio || 'Информация не заполнена')
                }
              </p>
            )}
          </div>

          {/* Skills for students */}
          {user.role === 'student' && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Навыки</h2>
              {isEditing ? (
                <input
                  type="text"
                  value={editForm.skills}
                  onChange={(e) => setEditForm({...editForm, skills: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="JavaScript, Python, Design... (через запятую)"
                />
              ) : (
                <div className="flex flex-wrap gap-2">
                  {user.skills && user.skills.length > 0 ? (
                    user.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium"
                      >
                        {skill}
                      </span>
                    ))
                  ) : (
                    <p className="text-gray-500">Навыки не указаны</p>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Website for companies */}
          {user.role === 'company' && user.companyInfo?.website && !isEditing && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Сайт компании</h2>
              <a
                href={user.companyInfo.website}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-700 underline"
              >
                {user.companyInfo.website}
              </a>
            </div>
          )}

          {/* Portfolio placeholder for students */}
          {user.role === 'student' && (
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Портфолио</h2>
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center">
                <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 mb-2">Ваше портфолио будет формироваться автоматически</p>
                <p className="text-gray-400 text-sm">по мере выполнения заданий</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};