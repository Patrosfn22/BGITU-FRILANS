import React, { useState } from 'react';
import { Plus, X, Building2, GraduationCap } from 'lucide-react';
import { Task } from '../types';
import { useAuth } from '../contexts/AuthContext';

interface CreateTaskProps {
  onPageChange: (page: string) => void;
}

export const CreateTask: React.FC<CreateTaskProps> = ({ onPageChange }) => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    skills: '',
    deadline: '',
    difficulty: 'medium' as 'easy' | 'medium' | 'hard',
    academicPoints: 0,
    payment: 0,
    category: 'academic' as 'academic' | 'commercial' | 'internship' | 'competition',
    priority: 'medium' as 'low' | 'medium' | 'high' | 'urgent',
    estimatedHours: 0,
    isRemote: true,
    location: '',
    requirements: '',
    deliverables: '',
    tags: ''
  });
  const [loading, setLoading] = useState(false);

  if (!user || (user.role !== 'teacher' && user.role !== 'company')) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <p className="text-gray-500">У вас нет прав для создания заданий</p>
        </div>
      </div>
    );
  }

  const isCompany = user.role === 'company';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const existingTasks = JSON.parse(localStorage.getItem('tasks') || '[]');
      
      const newTask: Task = {
        id: Date.now().toString(),
        title: formData.title,
        description: formData.description,
        authorId: user.id,
        authorName: user.name,
        authorType: user.role === 'company' ? 'company' : 'teacher',
        companyInfo: user.companyInfo,
        skills: formData.skills.split(',').map(s => s.trim()).filter(s => s),
        deadline: formData.deadline,
        difficulty: formData.difficulty,
        academicPoints: isCompany ? 0 : formData.academicPoints,
        payment: isCompany ? formData.payment : 0,
        status: 'open',
        applicants: [],
        createdAt: new Date().toISOString(),
        category: formData.category,
        priority: formData.priority,
        estimatedHours: formData.estimatedHours,
        isRemote: formData.isRemote,
        location: formData.isRemote ? undefined : formData.location,
        requirements: formData.requirements.split('\n').filter(r => r.trim()),
        deliverables: formData.deliverables.split('\n').filter(d => d.trim()),
        tags: formData.tags.split(',').map(t => t.trim()).filter(t => t)
      };

      const updatedTasks = [...existingTasks, newTask];
      localStorage.setItem('tasks', JSON.stringify(updatedTasks));

      // Reset form
      setFormData({
        title: '',
        description: '',
        skills: '',
        deadline: '',
        difficulty: 'medium',
        academicPoints: 0,
        payment: 0,
        category: 'academic',
        priority: 'medium',
        estimatedHours: 0,
        isRemote: true,
        location: '',
        requirements: '',
        deliverables: '',
        tags: ''
      });

      // Redirect to dashboard
      onPageChange('dashboard');
    } catch (error) {
      console.error('Error creating task:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            {isCompany ? (
              <div className="p-3 bg-blue-100 rounded-xl">
                <Building2 className="h-6 w-6 text-blue-600" />
              </div>
            ) : (
              <div className="p-3 bg-purple-100 rounded-xl">
                <GraduationCap className="h-6 w-6 text-purple-600" />
              </div>
            )}
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {isCompany ? 'Создать коммерческое задание' : 'Создать академическое задание'}
              </h1>
              <p className="text-gray-600 mt-1">
                {isCompany 
                  ? 'Опубликуйте проект для талантливых студентов' 
                  : 'Создайте задание для развития навыков студентов'
                }
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Название задания *
              </label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Введите название задания"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Описание задания *
              </label>
              <textarea
                required
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={6}
                placeholder="Подробно опишите задание, требования и ожидаемый результат"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Необходимые навыки *
              </label>
              <input
                type="text"
                required
                value={formData.skills}
                onChange={(e) => setFormData({...formData, skills: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="JavaScript, Python, Design... (через запятую)"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Дедлайн *
              </label>
              <input
                type="date"
                required
                value={formData.deadline}
                onChange={(e) => setFormData({...formData, deadline: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Категория
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value as any})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {isCompany ? (
                  <>
                    <option value="commercial">Коммерческий проект</option>
                    <option value="internship">Стажировка</option>
                    <option value="competition">Конкурс</option>
                  </>
                ) : (
                  <>
                    <option value="academic">Академическое задание</option>
                    <option value="competition">Конкурс</option>
                  </>
                )}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Уровень сложности
              </label>
              <select
                value={formData.difficulty}
                onChange={(e) => setFormData({...formData, difficulty: e.target.value as 'easy' | 'medium' | 'hard'})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="easy">Легкий</option>
                <option value="medium">Средний</option>
                <option value="hard">Сложный</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Приоритет
              </label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({...formData, priority: e.target.value as any})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="low">Низкий</option>
                <option value="medium">Средний</option>
                <option value="high">Высокий</option>
                <option value="urgent">Срочный</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ориентировочное время (часы)
              </label>
              <input
                type="number"
                min="1"
                value={formData.estimatedHours}
                onChange={(e) => setFormData({...formData, estimatedHours: parseInt(e.target.value) || 0})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="40"
              />
            </div>

            {!isCompany && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Академические баллы *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  value={formData.academicPoints}
                  onChange={(e) => setFormData({...formData, academicPoints: parseInt(e.target.value) || 0})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="50"
                />
              </div>
            )}

            {isCompany && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Оплата (₽) *
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  value={formData.payment}
                  onChange={(e) => setFormData({...formData, payment: parseInt(e.target.value) || 0})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="50000"
                />
              </div>
            )}
          </div>

          {/* Location settings */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                id="isRemote"
                checked={formData.isRemote}
                onChange={(e) => setFormData({...formData, isRemote: e.target.checked})}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="isRemote" className="text-sm font-medium text-gray-700">
                Удаленная работа
              </label>
            </div>

            {!formData.isRemote && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Местоположение
                </label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Москва, офис компании"
                />
              </div>
            )}
          </div>

          {/* Additional fields */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Требования (каждое с новой строки)
              </label>
              <textarea
                value={formData.requirements}
                onChange={(e) => setFormData({...formData, requirements: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={4}
                placeholder="Опыт работы с React&#10;Знание TypeScript&#10;Портфолио проектов"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ожидаемые результаты (каждый с новой строки)
              </label>
              <textarea
                value={formData.deliverables}
                onChange={(e) => setFormData({...formData, deliverables: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={4}
                placeholder="Рабочее приложение&#10;Исходный код&#10;Документация&#10;Презентация результатов"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Теги (через запятую)
            </label>
            <input
              type="text"
              value={formData.tags}
              onChange={(e) => setFormData({...formData, tags: e.target.value})}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Веб-разработка, Стартап, Инновации"
            />
          </div>

          <div className="flex space-x-4 pt-6">
            <button
              type="button"
              onClick={() => onPageChange('dashboard')}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Отмена
            </button>
            <button
              type="submit"
              disabled={loading}
              className={`flex-1 text-white px-6 py-3 rounded-lg transition-colors font-medium disabled:opacity-50 flex items-center justify-center space-x-2 ${
                isCompany
                  ? 'bg-blue-600 hover:bg-blue-700'
                  : 'bg-purple-600 hover:bg-purple-700'
              }`}
            >
              {loading ? (
                <span>Создание...</span>
              ) : (
                <>
                  <Plus className="h-4 w-4" />
                  <span>Создать задание</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};