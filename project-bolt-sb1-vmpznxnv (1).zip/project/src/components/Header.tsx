import React, { useState } from 'react';
import { User, LogOut, Award, Bell, Menu } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Logo } from './Logo';
import { NotificationCenter } from './NotificationCenter';

interface HeaderProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, onPageChange }) => {
  const { user, logout } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);

  if (!user) return null;

  const unreadNotifications = user.notifications?.filter(n => !n.read).length || 0;

  return (
    <>
      <header className="bg-white/80 backdrop-blur-lg shadow-sm border-b border-gray-200/50 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Logo size="sm" />
            
            <nav className="hidden md:flex space-x-1">
              <button
                onClick={() => onPageChange('dashboard')}
                className={`px-4 py-2 text-sm font-medium rounded-xl transition-all duration-200 ${
                  currentPage === 'dashboard'
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                Задания
              </button>
              
              {user.role === 'student' && (
                <button
                  onClick={() => onPageChange('my-applications')}
                  className={`px-4 py-2 text-sm font-medium rounded-xl transition-all duration-200 ${
                    currentPage === 'my-applications'
                      ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  Мои заявки
                </button>
              )}
              
              {user.role === 'teacher' && (
                <button
                  onClick={() => onPageChange('create-task')}
                  className={`px-4 py-2 text-sm font-medium rounded-xl transition-all duration-200 ${
                    currentPage === 'create-task'
                      ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  Создать задание
                </button>
              )}
              
              <button
                onClick={() => onPageChange('profile')}
                className={`px-4 py-2 text-sm font-medium rounded-xl transition-all duration-200 ${
                  currentPage === 'profile'
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                Профиль
              </button>
            </nav>
            
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setShowNotifications(true)}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors relative"
              >
                <Bell className="h-5 w-5" />
                {unreadNotifications > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-medium">
                    {unreadNotifications > 9 ? '9+' : unreadNotifications}
                  </span>
                )}
              </button>
              
              {user.role === 'student' && (
                <div className="hidden sm:flex items-center space-x-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium shadow-lg">
                  <Award className="h-4 w-4" />
                  <span>{user.academicPoints} АБ</span>
                </div>
              )}
              
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                    <User className="h-4 w-4 text-white" />
                  </div>
                  <div className="hidden sm:block">
                    <span className="text-sm font-medium text-gray-700">{user.name}</span>
                    <p className="text-xs text-gray-500 capitalize">{user.role === 'student' ? 'Студент' : 'Преподаватель'}</p>
                  </div>
                </div>
                
                <button
                  onClick={logout}
                  className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <NotificationCenter 
        isOpen={showNotifications} 
        onClose={() => setShowNotifications(false)} 
      />
    </>
  );
};