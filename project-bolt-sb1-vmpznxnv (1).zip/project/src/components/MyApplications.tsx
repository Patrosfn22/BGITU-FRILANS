import React, { useState, useEffect } from 'react';
import { Clock, CheckCircle, XCircle, AlertCircle, Calendar, DollarSign, Award } from 'lucide-react';
import { Task, Application } from '../types';
import { useAuth } from '../contexts/AuthContext';

export const MyApplications: React.FC = () => {
  const { user } = useAuth();
  const [applications, setApplications] = useState<(Application & { task: Task })[]>([]);

  useEffect(() => {
    if (!user) return;

    // Получаем все задания и фильтруем заявки текущего пользователя
    const tasks: Task[] = JSON.parse(localStorage.getItem('tasks') || '[]');
    const userApplications: (Application & { task: Task })[] = [];

    tasks.forEach(task => {
      if (task.applicants) {
        task.applicants.forEach(application => {
          if (application.studentId === user.id) {
            userApplications.push({ ...application, task });
          }
        });
      }
    });

    setApplications(userApplications.sort((a, b) => 
      new Date(b.appliedAt).getTime() - new Date(a.appliedAt).getTime()
    ));
  }, [user]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'accepted':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return <AlertCircle className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'accepted': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Ожидает рассмотрения';
      case 'accepted': return 'Принята - можете приступать!';
      case 'rejected': return 'Отклонена';
      default: return status;
    }
  };

  if (applications.length === 0) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="h-16 w-16 text-gray-300 mx-auto mb-4" />
        <p className="text-gray-500 text-lg">У вас пока нет заявок</p>
        <p className="text-gray-400">Подавайте заявки на интересные задания!</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Мои заявки</h2>
      
      <div className="space-y-4">
        {applications.map((application) => (
          <div key={application.id} className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{application.task.title}</h3>
                <p className="text-gray-600 mb-3 line-clamp-2">{application.task.description}</p>
                
                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>Дедлайн: {new Date(application.task.deadline).toLocaleDateString('ru-RU')}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Award className="h-4 w-4 text-yellow-500" />
                    <span>{application.task.academicPoints} АБ</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <DollarSign className="h-4 w-4 text-green-500" />
                    <span>{application.task.payment}₽</span>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col items-end space-y-2">
                <div className={`flex items-center space-x-2 px-3 py-1 rounded-full border ${getStatusColor(application.status)}`}>
                  {getStatusIcon(application.status)}
                  <span className="text-sm font-medium">{getStatusText(application.status)}</span>
                </div>
                <span className="text-sm text-gray-500">
                  Подана: {new Date(application.appliedAt).toLocaleDateString('ru-RU')}
                </span>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm font-medium text-gray-700 mb-2">Ваше сообщение:</p>
              <p className="text-gray-600 text-sm">{application.message}</p>
            </div>

            {application.status === 'accepted' && (
              <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center space-x-2 text-green-800">
                  <CheckCircle className="h-5 w-5" />
                  <p className="font-medium">Поздравляем! Ваша заявка принята.</p>
                </div>
                <p className="text-green-700 text-sm mt-1">
                  Свяжитесь с преподавателем для получения дополнительных инструкций.
                </p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};