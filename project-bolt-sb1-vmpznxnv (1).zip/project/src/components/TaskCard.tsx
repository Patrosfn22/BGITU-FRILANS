import React from 'react';
import { Calendar, DollarSign, Award, User, Star, Clock, TrendingUp, Building2, GraduationCap, MapPin, Zap } from 'lucide-react';
import { Task } from '../types';

interface TaskCardProps {
  task: Task;
  onApply?: (taskId: string) => void;
  onViewDetails?: (taskId: string) => void;
  currentUserId?: string;
  userRole?: string;
}

export const TaskCard: React.FC<TaskCardProps> = ({ 
  task, 
  onApply, 
  onViewDetails, 
  currentUserId,
  userRole 
}) => {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'medium': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'hard': return 'bg-rose-100 text-rose-800 border-rose-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getDifficultyText = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'Легкий';
      case 'medium': return 'Средний';
      case 'hard': return 'Сложный';
      default: return difficulty;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-green-100 text-green-800 border-green-200';
      case 'in_progress': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'completed': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'closed': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'open': return 'Открыто';
      case 'in_progress': return 'В работе';
      case 'completed': return 'Завершено';
      case 'closed': return 'Закрыто';
      default: return status;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'commercial': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'academic': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'internship': return 'bg-green-100 text-green-800 border-green-200';
      case 'competition': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getCategoryText = (category: string) => {
    switch (category) {
      case 'commercial': return 'Коммерческий';
      case 'academic': return 'Академический';
      case 'internship': return 'Стажировка';
      case 'competition': return 'Конкурс';
      default: return category;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'text-red-600';
      case 'high': return 'text-orange-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const canApply = userRole === 'student' && task.status === 'open' && task.authorId !== currentUserId;
  const daysLeft = Math.ceil((new Date(task.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
  const isCompanyTask = task.authorType === 'company';

  return (
    <div className={`bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 p-6 border ${
      isCompanyTask ? 'border-blue-200 hover:border-blue-300' : 'border-gray-100 hover:border-purple-200'
    } transform hover:scale-[1.02] group relative overflow-hidden`}>
      
      {/* Company/Academic indicator */}
      <div className={`absolute top-0 left-0 w-full h-1 ${
        isCompanyTask ? 'bg-gradient-to-r from-blue-500 to-cyan-500' : 'bg-gradient-to-r from-purple-500 to-pink-500'
      }`}></div>

      {/* Priority indicator */}
      {task.priority === 'urgent' && (
        <div className="absolute top-4 left-4">
          <div className="flex items-center space-x-1 bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-semibold">
            <Zap className="h-3 w-3" />
            <span>Срочно</span>
          </div>
        </div>
      )}

      <div className="flex justify-between items-start mb-4 mt-2">
        <h3 className="text-xl font-bold text-gray-900 flex-1 mr-4 group-hover:text-blue-600 transition-colors">
          {task.title}
        </h3>
        <div className="flex flex-col space-y-2">
          <div className="flex space-x-2">
            <span className={`px-3 py-1 text-xs font-semibold rounded-full border ${getDifficultyColor(task.difficulty)}`}>
              {getDifficultyText(task.difficulty)}
            </span>
            <span className={`px-3 py-1 text-xs font-semibold rounded-full border ${getStatusColor(task.status)}`}>
              {getStatusText(task.status)}
            </span>
          </div>
          <span className={`px-3 py-1 text-xs font-semibold rounded-full border ${getCategoryColor(task.category)} self-end`}>
            {getCategoryText(task.category)}
          </span>
        </div>
      </div>
      
      <p className="text-gray-600 mb-4 line-clamp-3 leading-relaxed">{task.description}</p>
      
      {/* Author info with enhanced company display */}
      <div className="flex items-center space-x-3 mb-4">
        <div className={`p-2 rounded-lg ${isCompanyTask ? 'bg-blue-100' : 'bg-purple-100'}`}>
          {isCompanyTask ? (
            <Building2 className={`h-4 w-4 ${isCompanyTask ? 'text-blue-600' : 'text-purple-600'}`} />
          ) : (
            <GraduationCap className="h-4 w-4 text-purple-600" />
          )}
        </div>
        <div>
          <p className="text-sm font-semibold text-gray-900">{task.authorName}</p>
          {isCompanyTask && task.companyInfo && (
            <div className="flex items-center space-x-2 text-xs text-gray-600">
              <span>{task.companyInfo.industry}</span>
              <span>•</span>
              <span className="capitalize">{task.companyInfo.partnershipLevel} партнер</span>
            </div>
          )}
        </div>
      </div>

      {/* Location and remote info */}
      {(task.location || task.isRemote) && (
        <div className="flex items-center space-x-2 mb-4 text-sm text-gray-600">
          <MapPin className="h-4 w-4" />
          <span>{task.isRemote ? 'Удаленно' : task.location}</span>
        </div>
      )}
      
      <div className="flex flex-wrap gap-2 mb-5">
        {task.skills.slice(0, 3).map((skill) => (
          <span
            key={skill}
            className={`px-3 py-1 text-xs font-semibold rounded-lg border ${
              isCompanyTask 
                ? 'bg-gradient-to-r from-blue-50 to-cyan-50 text-blue-700 border-blue-100'
                : 'bg-gradient-to-r from-purple-50 to-pink-50 text-purple-700 border-purple-100'
            }`}
          >
            {skill}
          </span>
        ))}
        {task.skills.length > 3 && (
          <span className="px-3 py-1 bg-gray-100 text-gray-600 text-xs font-medium rounded-lg">
            +{task.skills.length - 3}
          </span>
        )}
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-5">
        <div className="flex items-center space-x-2 text-sm">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Calendar className="h-4 w-4 text-blue-600" />
          </div>
          <div>
            <p className="text-gray-500 text-xs">Дедлайн</p>
            <p className="font-semibold text-gray-900">{new Date(task.deadline).toLocaleDateString('ru-RU')}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2 text-sm">
          <div className="p-2 bg-orange-100 rounded-lg">
            <Clock className="h-4 w-4 text-orange-600" />
          </div>
          <div>
            <p className="text-gray-500 text-xs">Осталось</p>
            <p className={`font-semibold ${daysLeft <= 3 ? 'text-red-600' : 'text-gray-900'}`}>
              {daysLeft} дн.
            </p>
          </div>
        </div>
      </div>
      
      {/* Enhanced reward section */}
      <div className={`flex items-center justify-between mb-6 p-4 rounded-xl ${
        isCompanyTask 
          ? 'bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-100'
          : 'bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-100'
      }`}>
        <div className="flex items-center space-x-4">
          {task.academicPoints > 0 && (
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Award className="h-4 w-4 text-yellow-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">Баллы</p>
                <p className="font-bold text-gray-900">{task.academicPoints} АБ</p>
              </div>
            </div>
          )}
          
          {task.payment > 0 && (
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-green-100 rounded-lg">
                <DollarSign className="h-4 w-4 text-green-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">Оплата</p>
                <p className="font-bold text-gray-900">{task.payment.toLocaleString()}₽</p>
              </div>
            </div>
          )}

          {task.estimatedHours && (
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-indigo-100 rounded-lg">
                <Clock className="h-4 w-4 text-indigo-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">Часов</p>
                <p className="font-bold text-gray-900">{task.estimatedHours}ч</p>
              </div>
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-1 text-xs text-gray-500">
          <TrendingUp className="h-3 w-3" />
          <span>{task.applicants?.length || 0} откликов</span>
        </div>
      </div>

      {/* Tags */}
      {task.tags && task.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-4">
          {task.tags.map((tag) => (
            <span
              key={tag}
              className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-md"
            >
              #{tag}
            </span>
          ))}
        </div>
      )}
      
      <div className="flex space-x-3">
        {canApply && (
          <button
            onClick={() => onApply?.(task.id)}
            className={`flex-1 text-white px-6 py-3 rounded-xl transition-all duration-200 font-semibold shadow-lg hover:shadow-xl transform hover:scale-[1.02] ${
              isCompanyTask
                ? 'bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700'
                : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700'
            }`}
          >
            Откликнуться
          </button>
        )}
        
        <button
          onClick={() => onViewDetails?.(task.id)}
          className="px-6 py-3 border-2 border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-all duration-200 font-semibold"
        >
          Подробнее
        </button>
      </div>
    </div>
  );
};