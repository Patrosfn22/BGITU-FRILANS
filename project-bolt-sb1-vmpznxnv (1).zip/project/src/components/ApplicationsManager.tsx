import React, { useState, useEffect } from 'react';
import { User, Clock, CheckCircle, XCircle, Star, Mail } from 'lucide-react';
import { Task, Application } from '../types';
import { useAuth } from '../contexts/AuthContext';

interface ApplicationsManagerProps {
  task: Task;
  onClose: () => void;
  onTaskUpdate: (updatedTask: Task) => void;
}

export const ApplicationsManager: React.FC<ApplicationsManagerProps> = ({ 
  task, 
  onClose, 
  onTaskUpdate 
}) => {
  const { user } = useAuth();
  const [applications, setApplications] = useState<Application[]>(task.applicants || []);

  const handleApplicationAction = (applicationId: string, action: 'accept' | 'reject') => {
    const updatedApplications = applications.map(app => {
      if (app.id === applicationId) {
        return { ...app, status: action === 'accept' ? 'accepted' as const : 'rejected' as const };
      }
      return app;
    });

    const acceptedApplication = updatedApplications.find(app => app.status === 'accepted');
    
    const updatedTask: Task = {
      ...task,
      applicants: updatedApplications,
      status: acceptedApplication ? 'in_progress' : task.status,
      assignedTo: acceptedApplication?.studentId,
      assignedToName: acceptedApplication?.studentName
    };

    setApplications(updatedApplications);
    onTaskUpdate(updatedTask);

    // Создаем уведомление для студента
    const notification = {
      id: Date.now().toString(),
      userId: updatedApplications.find(app => app.id === applicationId)?.studentId || '',
      type: 'application_status' as const,
      title: action === 'accept' ? 'Заявка принята!' : 'Заявка отклонена',
      message: action === 'accept' 
        ? `Ваша заявка на задание "${task.title}" была принята. Можете приступать к работе!`
        : `Ваша заявка на задание "${task.title}" была отклонена.`,
      read: false,
      createdAt: new Date().toISOString(),
      relatedTaskId: task.id,
      relatedApplicationId: applicationId
    };

    // Здесь бы в реальном приложении отправили уведомление через API
    console.log('Notification created:', notification);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'accepted': return 'text-green-600 bg-green-100';
      case 'rejected': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Ожидает';
      case 'accepted': return 'Принята';
      case 'rejected': return 'Отклонена';
      default: return status;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-hidden shadow-2xl">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-bold text-gray-900">Заявки на задание</h3>
              <p className="text-gray-600 mt-1">{task.title}</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
            >
              <XCircle className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[70vh] p-6">
          {applications.length === 0 ? (
            <div className="text-center py-12">
              <User className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">Заявок пока нет</p>
              <p className="text-gray-400">Студенты смогут подавать заявки на ваше задание</p>
            </div>
          ) : (
            <div className="space-y-6">
              {applications.map((application) => (
                <div key={application.id} className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                        <User className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold text-gray-900">{application.studentName}</h4>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-4 w-4" />
                          <span>{application.studentEmail}</span>
                        </div>
                        {application.studentRating && (
                          <div className="flex items-center space-x-1 mt-1">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="text-sm text-gray-600">{application.studentRating.toFixed(1)}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(application.status)}`}>
                        {getStatusText(application.status)}
                      </span>
                      <span className="text-sm text-gray-500">
                        {new Date(application.appliedAt).toLocaleDateString('ru-RU')}
                      </span>
                    </div>
                  </div>

                  {application.studentSkills && application.studentSkills.length > 0 && (
                    <div className="mb-4">
                      <p className="text-sm font-medium text-gray-700 mb-2">Навыки:</p>
                      <div className="flex flex-wrap gap-2">
                        {application.studentSkills.map((skill) => (
                          <span
                            key={skill}
                            className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-lg"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-700 mb-2">Сообщение:</p>
                    <p className="text-gray-600 bg-white p-4 rounded-lg border">{application.message}</p>
                  </div>

                  {application.status === 'pending' && (
                    <div className="flex space-x-3">
                      <button
                        onClick={() => handleApplicationAction(application.id, 'accept')}
                        className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors font-medium flex items-center justify-center space-x-2"
                      >
                        <CheckCircle className="h-4 w-4" />
                        <span>Принять</span>
                      </button>
                      <button
                        onClick={() => handleApplicationAction(application.id, 'reject')}
                        className="flex-1 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors font-medium flex items-center justify-center space-x-2"
                      >
                        <XCircle className="h-4 w-4" />
                        <span>Отклонить</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};