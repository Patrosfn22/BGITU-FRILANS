import React, { useState, useEffect } from 'react';
import { Search, Filter, Plus, Sparkles, TrendingUp, Users, Eye, Building2, GraduationCap, MapPin, Clock, Star } from 'lucide-react';
import { Task } from '../types';
import { TaskCard } from './TaskCard';
import { ApplicationsManager } from './ApplicationsManager';
import { useAuth } from '../contexts/AuthContext';

interface DashboardProps {
  onPageChange: (page: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onPageChange }) => {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [filteredTasks, setFilteredTasks] = useState<Task[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [skillFilter, setSkillFilter] = useState('');
  const [difficultyFilter, setDifficultyFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [authorTypeFilter, setAuthorTypeFilter] = useState('');
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState('');
  const [applicationMessage, setApplicationMessage] = useState('');
  const [proposedTimeline, setProposedTimeline] = useState('');
  const [showApplicationsManager, setShowApplicationsManager] = useState(false);
  const [selectedTaskForApplications, setSelectedTaskForApplications] = useState<Task | null>(null);

  useEffect(() => {
    const savedTasks = localStorage.getItem('tasks');
    if (!savedTasks) {
      const sampleTasks: Task[] = [
        {
          id: '1',
          title: 'Разработка мобильного приложения для банка',
          description: 'Создать современное мобильное приложение для интернет-банкинга с использованием React Native. Приложение должно включать систему безопасности, переводы, платежи и аналитику расходов. Проект от ведущего банка России.',
          authorId: 'company1',
          authorName: 'Сбербанк',
          authorType: 'company',
          companyInfo: {
            companyName: 'Сбербанк',
            industry: 'Финансы',
            website: 'sberbank.ru',
            description: 'Крупнейший банк России и Восточной Европы',
            size: 'large',
            partnershipLevel: 'platinum'
          },
          skills: ['React Native', 'JavaScript', 'Firebase', 'UI/UX Design', 'Security'],
          deadline: '2025-04-15',
          difficulty: 'hard',
          academicPoints: 0,
          payment: 150000,
          status: 'open',
          applicants: [],
          createdAt: '2025-01-01',
          category: 'commercial',
          priority: 'high',
          estimatedHours: 200,
          isRemote: true,
          tags: ['Финтех', 'Мобильная разработка', 'Безопасность']
        },
        {
          id: '2',
          title: 'Дизайн корпоративного сайта БГИТУ',
          description: 'Разработать современный дизайн официального сайта университета с учетом принципов UX/UI. Создать адаптивный макет, систему навигации и фирменный стиль. Работа включает исследование пользователей и создание интерактивных прототипов.',
          authorId: 'teacher2',
          authorName: 'Доц. Петрова М.С.',
          authorType: 'teacher',
          skills: ['UI/UX Design', 'Figma', 'Adobe Creative Suite', 'Prototyping'],
          deadline: '2025-02-28',
          difficulty: 'medium',
          academicPoints: 50,
          payment: 0,
          status: 'open',
          applicants: [],
          createdAt: '2025-01-02',
          category: 'academic',
          priority: 'medium',
          estimatedHours: 80,
          isRemote: false,
          location: 'БГИТУ, корп. 1',
          tags: ['Образование', 'Веб-дизайн']
        },
        {
          id: '3',
          title: 'Анализ данных для Яндекс.Маркет',
          description: 'Провести комплексный анализ поведения пользователей на платформе Яндекс.Маркет. Создать дашборды, выявить закономерности покупательского поведения и подготовить рекомендации для улучшения конверсии.',
          authorId: 'company2',
          authorName: 'Яндекс',
          authorType: 'company',
          companyInfo: {
            companyName: 'Яндекс',
            industry: 'IT/Технологии',
            website: 'yandex.ru',
            description: 'Российская транснациональная IT-компания',
            size: 'large',
            partnershipLevel: 'gold'
          },
          skills: ['Python', 'Data Science', 'Pandas', 'Tableau', 'SQL', 'Machine Learning'],
          deadline: '2025-03-20',
          difficulty: 'hard',
          academicPoints: 0,
          payment: 120000,
          status: 'open',
          applicants: [],
          createdAt: '2025-01-03',
          category: 'commercial',
          priority: 'high',
          estimatedHours: 160,
          isRemote: true,
          tags: ['Big Data', 'E-commerce', 'Аналитика']
        },
        {
          id: '4',
          title: 'Создание чат-бота для поддержки студентов',
          description: 'Разработать интеллектуального чат-бота для помощи студентам в навигации по университетским сервисам. Бот должен отвечать на вопросы о расписании, оценках, мероприятиях и предоставлять полезную информацию.',
          authorId: 'teacher4',
          authorName: 'Каф. Информационных технологий',
          authorType: 'teacher',
          skills: ['Python', 'NLP', 'Telegram Bot API', 'Machine Learning'],
          deadline: '2025-02-20',
          difficulty: 'medium',
          academicPoints: 45,
          payment: 0,
          status: 'open',
          applicants: [],
          createdAt: '2025-01-04',
          category: 'academic',
          priority: 'medium',
          estimatedHours: 60,
          isRemote: true,
          tags: ['AI', 'Образование', 'Автоматизация']
        },
        {
          id: '5',
          title: 'Разработка системы управления складом для OZON',
          description: 'Создать веб-приложение для управления складскими операциями. Система должна включать учет товаров, отслеживание перемещений, генерацию отчетов и интеграцию с внешними API.',
          authorId: 'company3',
          authorName: 'OZON',
          authorType: 'company',
          companyInfo: {
            companyName: 'OZON',
            industry: 'E-commerce',
            website: 'ozon.ru',
            description: 'Крупнейшая российская интернет-торговая площадка',
            size: 'large',
            partnershipLevel: 'gold'
          },
          skills: ['React', 'Node.js', 'PostgreSQL', 'REST API', 'Docker'],
          deadline: '2025-05-01',
          difficulty: 'hard',
          academicPoints: 0,
          payment: 200000,
          status: 'open',
          applicants: [],
          createdAt: '2025-01-05',
          category: 'commercial',
          priority: 'urgent',
          estimatedHours: 300,
          isRemote: false,
          location: 'Москва, офис OZON',
          tags: ['Логистика', 'Веб-разработка', 'Enterprise']
        },
        {
          id: '6',
          title: 'Стажировка в команде разработки VK',
          description: 'Присоединиться к команде разработки социальной сети ВКонтакте на 3 месяца. Работа над реальными задачами, менторство от senior-разработчиков, возможность трудоустройства.',
          authorId: 'company4',
          authorName: 'VK (ВКонтакте)',
          authorType: 'company',
          companyInfo: {
            companyName: 'VK',
            industry: 'Социальные сети',
            website: 'vk.com',
            description: 'Ведущая российская IT-компания в сфере интернет-сервисов',
            size: 'large',
            partnershipLevel: 'platinum'
          },
          skills: ['JavaScript', 'React', 'PHP', 'MySQL', 'Git'],
          deadline: '2025-02-15',
          difficulty: 'medium',
          academicPoints: 0,
          payment: 80000,
          status: 'open',
          applicants: [],
          createdAt: '2025-01-06',
          category: 'internship',
          priority: 'high',
          estimatedHours: 480,
          isRemote: false,
          location: 'Санкт-Петербург, офис VK',
          tags: ['Стажировка', 'Социальные сети', 'Менторство']
        }
      ];
      localStorage.setItem('tasks', JSON.stringify(sampleTasks));
      setTasks(sampleTasks);
      setFilteredTasks(sampleTasks);
    } else {
      const parsedTasks = JSON.parse(savedTasks);
      setTasks(parsedTasks);
      setFilteredTasks(parsedTasks);
    }
  }, []);

  useEffect(() => {
    let filtered = tasks;

    if (searchTerm) {
      filtered = filtered.filter(task =>
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
        task.authorName.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (skillFilter) {
      filtered = filtered.filter(task =>
        task.skills.some(skill =>
          skill.toLowerCase().includes(skillFilter.toLowerCase())
        )
      );
    }

    if (difficultyFilter) {
      filtered = filtered.filter(task => task.difficulty === difficultyFilter);
    }

    if (categoryFilter) {
      filtered = filtered.filter(task => task.category === categoryFilter);
    }

    if (authorTypeFilter) {
      filtered = filtered.filter(task => task.authorType === authorTypeFilter);
    }

    setFilteredTasks(filtered);
  }, [tasks, searchTerm, skillFilter, difficultyFilter, categoryFilter, authorTypeFilter]);

  const handleApply = (taskId: string) => {
    setSelectedTaskId(taskId);
    setShowApplyModal(true);
  };

  const handleViewApplications = (task: Task) => {
    setSelectedTaskForApplications(task);
    setShowApplicationsManager(true);
  };

  const handleTaskUpdate = (updatedTask: Task) => {
    const updatedTasks = tasks.map(task => 
      task.id === updatedTask.id ? updatedTask : task
    );
    setTasks(updatedTasks);
    localStorage.setItem('tasks', JSON.stringify(updatedTasks));
  };

  const submitApplication = () => {
    if (!user || !selectedTaskId || !applicationMessage.trim()) return;

    const updatedTasks = tasks.map(task => {
      if (task.id === selectedTaskId) {
        const newApplication = {
          id: Date.now().toString(),
          studentId: user.id,
          studentName: user.name,
          studentEmail: user.email,
          taskId: selectedTaskId,
          message: applicationMessage,
          appliedAt: new Date().toISOString(),
          status: 'pending' as const,
          studentSkills: user.skills,
          studentRating: user.rating,
          proposedTimeline: proposedTimeline,
          expectedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
        };

        return {
          ...task,
          applicants: [...(task.applicants || []), newApplication]
        };
      }
      return task;
    });

    setTasks(updatedTasks);
    localStorage.setItem('tasks', JSON.stringify(updatedTasks));
    setShowApplyModal(false);
    setApplicationMessage('');
    setProposedTimeline('');
    setSelectedTaskId('');
  };

  const allSkills = Array.from(new Set(tasks.flatMap(task => task.skills)));
  const totalTasks = tasks.length;
  const openTasks = tasks.filter(task => task.status === 'open').length;
  const commercialTasks = tasks.filter(task => task.authorType === 'company').length;
  const academicTasks = tasks.filter(task => task.authorType === 'teacher').length;
  const totalReward = tasks.reduce((sum, task) => sum + task.payment, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex justify-between items-center mb-8">
            <div className="text-left">
              <h1 className="text-4xl font-bold text-gray-900 mb-2">
                Добро пожаловать в{' '}
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  BGITU Freelance Hub
                </span>
              </h1>
              <p className="text-xl text-gray-600">Найдите проекты от ведущих компаний и университета</p>
            </div>
            
            {(user?.role === 'teacher' || user?.role === 'company') && (
              <button
                onClick={() => onPageChange('create-task')}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-200 flex items-center space-x-2 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <Plus className="h-5 w-5" />
                <span>Создать задание</span>
              </button>
            )}
          </div>

          {/* Enhanced Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-blue-100 rounded-xl">
                  <Sparkles className="h-6 w-6 text-blue-600" />
                </div>
                <div className="text-left">
                  <p className="text-2xl font-bold text-gray-900">{totalTasks}</p>
                  <p className="text-gray-600">Всего заданий</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-green-100 rounded-xl">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <div className="text-left">
                  <p className="text-2xl font-bold text-gray-900">{openTasks}</p>
                  <p className="text-gray-600">Открытых заданий</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-purple-100 rounded-xl">
                  <Building2 className="h-6 w-6 text-purple-600" />
                </div>
                <div className="text-left">
                  <p className="text-2xl font-bold text-gray-900">{commercialTasks}</p>
                  <p className="text-gray-600">От компаний</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-orange-100 rounded-xl">
                  <GraduationCap className="h-6 w-6 text-orange-600" />
                </div>
                <div className="text-left">
                  <p className="text-2xl font-bold text-gray-900">{academicTasks}</p>
                  <p className="text-gray-600">Академических</p>
                </div>
              </div>
            </div>
          </div>

          {/* Partnership Banner */}
          <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 rounded-3xl p-8 mb-8 text-white">
            <div className="flex items-center justify-between">
              <div className="text-left">
                <h3 className="text-2xl font-bold mb-2">🚀 Партнерские проекты</h3>
                <p className="text-indigo-100 text-lg">Работайте с ведущими IT-компаниями России</p>
                <p className="text-indigo-200 text-sm mt-1">Сбербанк • Яндекс • VK • OZON • и другие</p>
              </div>
              <div className="text-right">
                <p className="text-3xl font-bold">{totalReward.toLocaleString()}₽</p>
                <p className="text-indigo-200">Общий призовой фонд</p>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Filters */}
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Поиск заданий, компаний, навыков..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 focus:bg-white"
              />
            </div>

            <select
              value={authorTypeFilter}
              onChange={(e) => setAuthorTypeFilter(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 focus:bg-white"
            >
              <option value="">Все заказчики</option>
              <option value="company">Компании</option>
              <option value="teacher">Университет</option>
            </select>

            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 focus:bg-white"
            >
              <option value="">Все категории</option>
              <option value="commercial">Коммерческие</option>
              <option value="academic">Академические</option>
              <option value="internship">Стажировки</option>
              <option value="competition">Конкурсы</option>
            </select>

            <select
              value={skillFilter}
              onChange={(e) => setSkillFilter(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 focus:bg-white"
            >
              <option value="">Все навыки</option>
              {allSkills.map(skill => (
                <option key={skill} value={skill}>{skill}</option>
              ))}
            </select>

            <select
              value={difficultyFilter}
              onChange={(e) => setDifficultyFilter(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 focus:bg-white"
            >
              <option value="">Все уровни</option>
              <option value="easy">Легкий</option>
              <option value="medium">Средний</option>
              <option value="hard">Сложный</option>
            </select>
          </div>
        </div>

        {/* Tasks Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {filteredTasks.map(task => (
            <div key={task.id} className="relative">
              <TaskCard
                task={task}
                onApply={handleApply}
                currentUserId={user?.id}
                userRole={user?.role}
              />
              
              {/* Enhanced controls for task authors */}
              {(user?.role === 'teacher' || user?.role === 'company') && task.authorId === user.id && (
                <div className="absolute top-4 right-4">
                  <button
                    onClick={() => handleViewApplications(task)}
                    className="bg-white/90 backdrop-blur-sm text-gray-700 p-2 rounded-lg hover:bg-white transition-colors shadow-lg border border-gray-200"
                    title="Просмотреть заявки"
                  >
                    <Eye className="h-4 w-4" />
                    {task.applicants && task.applicants.length > 0 && (
                      <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        {task.applicants.length}
                      </span>
                    )}
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredTasks.length === 0 && (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="h-12 w-12 text-gray-400" />
            </div>
            <p className="text-gray-500 text-xl font-medium">Заданий не найдено</p>
            <p className="text-gray-400 mt-2">Попробуйте изменить параметры поиска</p>
          </div>
        )}

        {/* Enhanced Apply Modal */}
        {showApplyModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-3xl w-full max-w-lg p-8 shadow-2xl border border-gray-100">
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Подать заявку</h3>
              <p className="text-gray-600 mb-6">
                Расскажите о своем опыте и подходе к решению задачи
              </p>
              
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Сопроводительное письмо *
                  </label>
                  <textarea
                    value={applicationMessage}
                    onChange={(e) => setApplicationMessage(e.target.value)}
                    placeholder="Опишите ваш опыт, подход к решению задачи и мотивацию..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 focus:bg-white"
                    rows={4}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Предполагаемые сроки выполнения
                  </label>
                  <input
                    type="text"
                    value={proposedTimeline}
                    onChange={(e) => setProposedTimeline(e.target.value)}
                    placeholder="Например: 2-3 недели"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 focus:bg-white"
                  />
                </div>
              </div>
              
              <div className="flex space-x-4">
                <button
                  onClick={() => setShowApplyModal(false)}
                  className="flex-1 px-6 py-3 border-2 border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-all duration-200 font-semibold"
                >
                  Отмена
                </button>
                <button
                  onClick={submitApplication}
                  disabled={!applicationMessage.trim()}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-200 disabled:opacity-50 font-semibold shadow-lg hover:shadow-xl transform hover:scale-[1.02] disabled:transform-none"
                >
                  Отправить заявку
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Applications Manager Modal */}
        {showApplicationsManager && selectedTaskForApplications && (
          <ApplicationsManager
            task={selectedTaskForApplications}
            onClose={() => {
              setShowApplicationsManager(false);
              setSelectedTaskForApplications(null);
            }}
            onTaskUpdate={handleTaskUpdate}
          />
        )}
      </div>
    </div>
  );
};