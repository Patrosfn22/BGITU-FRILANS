import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { Profile } from './components/Profile';
import { CreateTask } from './components/CreateTask';
import { MyApplications } from './components/MyApplications';
import { AuthModal } from './components/AuthModal';
import { Logo } from './components/Logo';

const AppContent: React.FC = () => {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [showAuthModal, setShowAuthModal] = useState(false);

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
        <div className="max-w-lg w-full">
          <div className="text-center mb-12">
            <Logo size="lg" className="justify-center mb-8" />
            <p className="text-2xl text-gray-600 mb-4 font-medium">Платформа фриланс-заданий БГИТУ</p>
            <p className="text-gray-500 text-lg leading-relaxed">
              Выбирайте интересные проекты, развивайте навыки и создавайте профессиональное портфолио
            </p>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">
            <div className="space-y-4 mb-8">
              <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200">
                <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                <span className="text-blue-900 font-medium">Система академических баллов</span>
              </div>
              <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-green-50 to-emerald-100 rounded-xl border border-green-200">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-green-900 font-medium">Автоматическое портфолио</span>
              </div>
              <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl border border-purple-200">
                <div className="w-3 h-3 bg-purple-500 rounded-full animate-pulse"></div>
                <span className="text-purple-900 font-medium">Рейтинг и профессиональные отзывы</span>
              </div>
              <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-orange-50 to-orange-100 rounded-xl border border-orange-200">
                <div className="w-3 h-3 bg-orange-500 rounded-full animate-pulse"></div>
                <span className="text-orange-900 font-medium">Реальные проекты от компаний</span>
              </div>
            </div>

            <button
              onClick={() => setShowAuthModal(true)}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 px-8 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-200 font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-[1.02]"
            >
              Начать работу
            </button>
            
            <p className="text-center text-gray-500 text-sm mt-4">
              Присоединяйтесь к сообществу студентов и преподавателей БГИТУ
            </p>
          </div>

          <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
        </div>
      </div>
    );
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onPageChange={setCurrentPage} />;
      case 'profile':
        return <Profile />;
      case 'create-task':
        return <CreateTask onPageChange={setCurrentPage} />;
      case 'my-applications':
        return <MyApplications />;
      default:
        return <Dashboard onPageChange={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header currentPage={currentPage} onPageChange={setCurrentPage} />
      <main className="pt-4">
        {renderCurrentPage()}
      </main>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;