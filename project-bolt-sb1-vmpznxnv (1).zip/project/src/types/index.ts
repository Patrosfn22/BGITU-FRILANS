export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'teacher' | 'company' | 'admin';
  avatar?: string;
  skills?: string[];
  bio?: string;
  rating?: number;
  academicPoints?: number;
  completedTasks?: number;
  totalEarnings?: number;
  notifications?: Notification[];
  portfolio?: PortfolioItem[];
  companyInfo?: CompanyInfo;
  verificationStatus?: 'pending' | 'verified' | 'rejected';
}

export interface CompanyInfo {
  companyName: string;
  industry: string;
  website?: string;
  description: string;
  logo?: string;
  size: 'startup' | 'small' | 'medium' | 'large';
  partnershipLevel: 'bronze' | 'silver' | 'gold' | 'platinum';
}

export interface Task {
  id: string;
  title: string;
  description: string;
  authorId: string;
  authorName: string;
  authorType: 'teacher' | 'company';
  companyInfo?: CompanyInfo;
  skills: string[];
  deadline: string;
  difficulty: 'easy' | 'medium' | 'hard';
  academicPoints: number;
  payment: number;
  status: 'open' | 'in_progress' | 'completed' | 'closed';
  applicants?: Application[];
  assignedTo?: string;
  assignedToName?: string;
  createdAt: string;
  requirements?: string[];
  deliverables?: string[];
  category: 'academic' | 'commercial' | 'internship' | 'competition';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  estimatedHours?: number;
  isRemote?: boolean;
  location?: string;
  tags?: string[];
}

export interface Application {
  id: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  taskId: string;
  message: string;
  portfolio?: string;
  appliedAt: string;
  status: 'pending' | 'accepted' | 'rejected';
  studentSkills?: string[];
  studentRating?: number;
  proposedTimeline?: string;
  expectedDelivery?: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'application_status' | 'new_task' | 'deadline_reminder' | 'task_completed' | 'new_application' | 'payment_received' | 'company_invitation';
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
  relatedTaskId?: string;
  relatedApplicationId?: string;
  actionUrl?: string;
}

export interface Review {
  id: string;
  taskId: string;
  studentId: string;
  reviewerId: string;
  reviewerType: 'teacher' | 'company';
  rating: number;
  comment: string;
  createdAt: string;
  skills?: string[];
  wouldRecommend?: boolean;
}

export interface PortfolioItem {
  id: string;
  taskId: string;
  title: string;
  description: string;
  skills: string[];
  completedAt: string;
  rating?: number;
  review?: string;
  clientType: 'teacher' | 'company';
  clientName: string;
  projectType: 'academic' | 'commercial';
  earnings?: number;
  academicPoints?: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  type: 'skill' | 'milestone' | 'rating' | 'earnings';
  requirement: number;
  reward?: {
    academicPoints?: number;
    badge?: string;
  };
}